/*************************************************************************************
			       DEPARTMENT OF ELECTRICAL AND ELECTRONIC ENGINEERING
					   		     IMPERIAL COLLEGE LONDON 

 				      EE 3.19: Real Time Digital Signal Processing
					       Dr Paul Mitcheson and Daniel Harvey

				        		  LAB 6: Frame Processing

 				            ********* F R A M E. C **********

  				Demonstrates Frame Processing (Interrupt driven) on the DSK. 

 *************************************************************************************
 				Updated for use on 6713 DSK by Danny Harvey: May-Aug 2006
				Updated for ccsV4 Sept 2010
 ************************************************************************************/
/*
 *	You should modify the code so that an FFT is applied to an input frame 
 *  which is then IFFT'd and sent to the audio port.
 */
/**************************** Pre-processor statements ******************************/

//  Included so program can make use of DSP/BIOS configuration tool.  
#include <stdlib.h>
#include "dsp_bios_cfg.h"

/* The file dsk6713.h must be included in every program that uses the BSL.  This 
   example also includes dsk6713_aic23.h because it uses the 
   AIC23 codec module (audio interface). */
#include "dsk6713.h"
#include "dsk6713_aic23.h"
#include "dsk6713_led.h" //for LEDs

// math library (trig functions)
#include <math.h>

/* Some functions to help with Complex algebra and FFT. */
#include "cmplx.h"
#include "fft_functions.h"

// Some functions to help with writing/reading the audio ports when using interrupts.
#include <helper_functions_ISR.h>
 
// clean database files for comparison
#include <elevenfft.txt>
 

/******************************* Global declarations ********************************/

/* Audio port configuration settings: these values set registers in the AIC23 audio 
   interface to configure it. See TI doc SLWS106D 3-3 to 3-10 for more info. */
DSK6713_AIC23_Config Config = { \
			 /**********************************************************************/
			 /*   REGISTER	            FUNCTION			      SETTINGS         */ 
			 /**********************************************************************/\
    0x0017,  /* 0 LEFTINVOL  Left line input channel volume  0dB                   */\
    0x0017,  /* 1 RIGHTINVOL Right line input channel volume 0dB                   */\
    0x01f9,  /* 2 LEFTHPVOL  Left channel headphone volume   0dB                   */\
    0x01f9,  /* 3 RIGHTHPVOL Right channel headphone volume  0dB                   */\
    0x0011,  /* 4 ANAPATH    Analog audio path control       DAC on, Mic boost 20dB*/\
    0x0000,  /* 5 DIGPATH    Digital audio path control      All Filters off       */\
    0x0000,  /* 6 DPOWERDOWN Power down control              All Hardware on       */\
    0x0043,  /* 7 DIGIF      Digital audio interface format  16 bit                */\
    0x008d,  /* 8 SAMPLERATE Sample rate control             8 KHZ                 */\
    0x0001   /* 9 DIGACT     Digital interface activation    On                    */\
			 /**********************************************************************/
};

// Codec handle:- a variable used to identify audio interface  
DSK6713_AIC23_CodecHandle H_Codec;

// PI defined here for use in your code 
#define PI 3.141592653589793

#define BUFLEN 512 //too many buffers with too big buflen, will run into memory issues

complex C[BUFLEN]; //complex buffer to store FFT
float *mag; //fft magnitudes

///////////////////Global variables for beep detection////////////////////////////
int present = 0; //bool to check if beep present
int silence = 1; //bool to check whether frame is silent

float freq_des = 2586.0; //beep freq, doesn't have to be very precise because fbin contains a range of freq
float fsamp = 8000.0;
int fbin=0; //fbin of freq_des for FFT of BUFLEN, initialised in main using fbin = freq_des/fsamp*BUFLEN;
float beep_amp; //magnitude of beep freq

float mag_sum; //sum of magnitudes across all freq
float thresh_sum = 0.5; //mag_sum threshold for frames to be determined as non-silent
float thresh; //beep magnitude threshold
float thresh_const=0.05; //beep threshold for silent frames
float max = 0; //max magnitude of freq bins
float alpha = 3.0; //thresh = max/alpha;


//////////////global variables for 'eleven' detection////////////////////////////
float corr_eleven=0;
float meanB, SUMB, SUMA, SUM, SD ; //vars used in calculating correlation
float corre_thresh = 0.90; //correlation threshold for eleven


//1 sec counter
int count11_1sec = 0;
int countbeep_1sec = 0;


////////////global variables for reading input and transferring to buffers/////////////////
/* Pointers to data buffers */                        
//buffers of length BUFLEN/2 for FFT with 50% overlap
float *in1;
float *in2;
float *mid1;
float *mid2;
float *out1;
float *out2;

//buffers containing windowed mid1, mid2
float *m1;
float *m2;

volatile int index = 0; //for filling up in, mid, out buffers

double sample; //sample read in via audio jack
int oneortwo = 1; //bool to switch between in1 and in2, out1 and out2


////////////global variables for 75% window overlap/////////////// 
//4 specs for 75% window overlap
float spec[BUFLEN];
float spec2[BUFLEN];
float spec3[BUFLEN];
float spec4[BUFLEN];
float window[BUFLEN]; //haming window initialised in init_arrays()

//indices for spec, spec2, spec3, spec4
int index2 = 0;
int index3 = 0;
int index4 = 0;
int index5 = 0;


int i; //for all for loops


 /******************************* Function prototypes *******************************/
void init_hardware(void);     
void init_HWI(void);   
void ISR_AIC(void);
void init_arrays(void);
void wait_buffer(void); 
void find_fft();
void calc_corr_eleven(float mag_spec[]);
void detect_beep(float mag_spec[]);
                       
/********************************** Main routine ************************************/
void main()
{
   DSK6713_LED_init();

   fbin = (int)(freq_des/fsamp*BUFLEN);
  /* setup arrays */
  init_arrays();  

	/* initialize board and the audio port */
  init_hardware();
	
  /* initialize hardware interrupts */
  init_HWI();

    
  /* loop indefinitely, waiting for interrupts */  					
  while(1) 
  {
  	  	wait_buffer();
  };
  
}

    
    
/********************************** init_hardware() *********************************/  
void init_hardware()
{
    // Initialize the board support library, must be called first 
    DSK6713_init();
    
    // Start the AIC23 codec using the settings defined above in config 
    H_Codec = DSK6713_AIC23_openCodec(0, &Config);

	/* Function below sets the number of bits in word used by MSBSP (serial port) for 
	receives from AIC23 (audio port). We are using a 32 bit packet containing two 
	16 bit numbers hence 32BIT is set for  receive */
	MCBSP_FSETS(RCR1, RWDLEN1, 32BIT);	

	/* Configures interrupt to activate on each consecutive available 32 bits 
	from Audio port hence an interrupt is generated for each L & R sample pair */	
	MCBSP_FSETS(SPCR1, RINTM, FRM);

	/* These commands do the same thing as above but applied to data transfers to 
	the audio port */
	MCBSP_FSETS(XCR1, XWDLEN1, 32BIT);	
	MCBSP_FSETS(SPCR1, XINTM, FRM);	
	

}
/********************************** init_HWI() **************************************/ 
void init_HWI(void)
{
	IRQ_globalDisable();			// Globally disables interrupts
	IRQ_nmiEnable();				// Enables the NMI interrupt (used by the debugger)
	IRQ_map(IRQ_EVT_RINT1,4);		// Maps an event to a physical interrupt
	IRQ_enable(IRQ_EVT_RINT1);		// Enables the event
	IRQ_globalEnable();				// Globally enables interrupts

} 
/************************** Allocate memory for arrays *******************************/        
void init_arrays(void)
{

    in1        = (float *) calloc(BUFLEN/2, sizeof(float));
    in2       = (float *) calloc(BUFLEN/2, sizeof(float));
    mid1       = (float *) calloc(BUFLEN/2, sizeof(float));
    mid2       = (float *) calloc(BUFLEN/2, sizeof(float));
    out1       = (float *) calloc(BUFLEN/2, sizeof(float));
    out2       = (float *) calloc(BUFLEN/2, sizeof(float));
    m1       = (float *) calloc(BUFLEN/2, sizeof(float));
    m2       = (float *) calloc(BUFLEN/2, sizeof(float));

    mag        = (float *) calloc(BUFLEN, sizeof(float));

    //init hamming window
    for (i=0; i<BUFLEN; i++) {
        window[i] = 0.54 - 0.46*cos(2*PI*i/BUFLEN);
    }
}

/*************************** INTERRUPT SERVICE ROUTINE  ******************************/

// Map this to the appropriate interrupt in the DSP BIOS

void ISR_AIC(void)
{       

	float scale = 11585;  
	
	sample = mono_read_16Bit();

	//switch between in1 and in2, out1 and out2
	if (oneortwo == 0) {
	    // add new data to input buffer
	    //  and scale so that 1v ~= 1.0
        in1[index] = ((float)sample)/scale;

        //write new output data
        mono_write_16Bit((short)(out1[index]*scale));
	}
	else {
	    in2[index] = ((float)sample)/scale;

	   //write new output data
	   mono_write_16Bit((short)(out2[index]*scale));
	}


	//detect eleven and light LED for one second
	if (corr_eleven>corre_thresh && count11_1sec==0) {
        count11_1sec = 1;
    }

	if (count11_1sec > 0 && count11_1sec < 8000) {
	    DSK6713_LED_on(3);
	    count11_1sec++;
	}
	else if (count11_1sec == 8000) {
	    DSK6713_LED_off(3);
	    count11_1sec = 0;
	}

	//detect beep and light LED for one second
	if (present==1 && countbeep_1sec == 0) {
        countbeep_1sec = 1;
    }
	if (countbeep_1sec > 0 && countbeep_1sec < 8000) {
	    DSK6713_LED_on(2);
	    countbeep_1sec++;
	}
    else if (countbeep_1sec == 8000){
        DSK6713_LED_off(2);
        countbeep_1sec = 0;
    }


	//update index and check for full buffer
	if (++index == BUFLEN/2){
		index=0;
	    oneortwo = 1- oneortwo;}

	//update index2 to index5 to achieve 75% overlap for buffers spec to spec4
	//add up 15 FFT frames (50% overlap) to form one FFT to represent 4096 input window
	if (index2 == 14) {
	    index2 = 0;
	}
	else {
	    index2 ++;
	}

	if (index2 == 3 || index3 == 14) {
        index3 = 0;
    }
    else {
        index3 ++;
    }

	if (index3 == 3 || index4 == 14) {
        index4 = 0;
    }
    else {
        index4 ++;
    }

	if (index4 == 3 || index5 == 14) {
        index5 = 0;
    }
    else {
        index5 ++;
    }

}

/******************* Wait for buffer of data to be input/output **********************/
void wait_buffer(void)
{
	float *p;

	/* wait for array index to be set to zero by ISR */
	while(index);
	
	/* rotate data arrays */
	p = in1;
    in1 = out2;
    out2 = out1;
    out1 = mid2;
    mid2 = mid1;
    mid1 = in2;
    in2 = p;
	
	/************************* DO PROCESSING OF FRAME  HERE **************************/
    //fft
    find_fft();

    //calculate correlation for all specs (achieve 75% overlap for windows)
    if (index2 == 14) {
        calc_corr_eleven(spec);
    }
    if (index3 == 14) {
        calc_corr_eleven(spec2);
    }
    if (index4 == 14) {
        calc_corr_eleven(spec3);
    }
    if (index5 == 14) {
        calc_corr_eleven(spec4);
    }

	//beep detection
    //FFT
	//copy values to complex variable to do fft
	for (i=0;i<BUFLEN/2;i++)
    {
        C[i] = cmplx(m1[i],0);
        C[i + BUFLEN/2] = cmplx(m2[i],0);
    }
	fft(BUFLEN, C);

	for (i=0; i<BUFLEN;i++) {
	    mag[i] = cabs(C[i]);
	}
	detect_beep(mag);
								/*please add your code */	    


	/**********************************************************************************/
	
	/* wait here in case next sample has not yet been read in */                          
	while(!index);
}        


//find fft of all four specs
void find_fft() {
    //reset spec to zero after every 15 frames
    if (index2 == 0) {
        for (i=0; i<BUFLEN; i++) {
            spec[i] = 0;
        }
    }

    if (index3 == 0) {
       for (i=0; i<BUFLEN; i++) {
           spec2[i] = 0;
       }
   }

    if (index4 == 0) {
       for (i=0; i<BUFLEN; i++) {
           spec3[i] = 0;
       }
   }

    if (index5 == 0) {
       for (i=0; i<BUFLEN; i++) {
           spec4[i] = 0;
       }
   }

    //windowing
    for (i=0; i<BUFLEN/2; i++) {
        m1[i] = window[i]*mid1[i];
        m2[i] = window[i+BUFLEN/2]*mid2[i];
    }

    //FFT
    //copy values to complex variable to do fft
    for (i=0;i<BUFLEN/2;i++)
    {
        C[i] = cmplx(m1[i],0);
        C[i + BUFLEN/2] = cmplx(m2[i],0);
    }

    fft(BUFLEN, C);

    for (i=0; i<BUFLEN;i++) {
        spec[i] += cabs(C[i]);
        spec2[i] += cabs(C[i]);
        spec3[i] += cabs(C[i]);
        spec4[i] += cabs(C[i]);
    }


}

//calculate correlation
void calc_corr_eleven(float mag_spec[]) {
    float sumB= 0;
    for (i=0; i<BUFLEN; i++) {
        sumB += mag_spec[i];
    }
    meanB = sumB/BUFLEN;
    SD=0;

    for(i=0;i<BUFLEN;i++){
        SD += pow(mag_spec[i]-meanB,2);
    }
    SD = sqrt(SD/BUFLEN);

    SUM = 0;
    for(i=0;i<BUFLEN;i++){
        SUMB = mag_spec[i]-meanB;
        SUMA = elevenfft[i]-meanA;
        SUM += SUMA*SUMB;
    }

    corr_eleven = SUM/SD/stdA/(BUFLEN-1);
}

//detect beep
void detect_beep(float mag_spec[]) {

    //check for silent frame
    mag_sum = 0;
    for (i=0; i<BUFLEN; i++) {
        mag_sum += mag_spec[i];
    }
    if (mag_sum > thresh_sum) {
        silence = 0;
    }
    else {
        silence = 1;
    }

    //if not silent, thresh is max/alpha
    max = 0;
    if (!silence) {
        for (i=0; i < BUFLEN; i++) {
            if (mag_spec[i] > max) {
                max = mag_spec[i];
            }
        }

        thresh = max/alpha;
    }
    else {
        thresh = thresh_const; //min threshold
    }

    beep_amp = mag_spec[fbin];
    if (beep_amp > thresh) {
        present = 1;
    }
    else {
        present = 0;
    }
}
