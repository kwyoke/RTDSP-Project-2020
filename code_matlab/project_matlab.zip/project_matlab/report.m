%% read audio inputs
[eleven, Fs] = audioread('eleven_8k.wav');
eleven = eleven(1000:5095);
[beep, Fs] = audioread('beep_8k.wav');
[journey, Fs] = audioread('journey_no_noise_8k.wav');
[noisy, Fs] = audioread('noisy_journey_8k.wav');
beeps_noisy = journey(36001:36000+length(eleven));
six = journey(112001:112000+length(eleven));
talking = noisy(10001:10000+length(eleven));
eleven_noisy = eleven + beeps_noisy; %synthetic noisy eleven
eleven_noisy2 = eleven + six; %six and eleven mixed
eleven_noisy3 = eleven + talking;
[kw_eleven, Fs] = audioread('kw_eleven.wav');
kw_eleven = kw_eleven(6000:10095);
[Eleven2, Fs] = audioread('Eleven8k.wav');
Eleven = Eleven2(175000:179905);
beeps2 = Eleven2(165000:170000);
doors = journey(128000:144000);
seven = journey(278000:282000);

%% Plot time domain, fft for beeps

%beeps
beep = [beep; zeros(4096-3998,1)];
beeps_noisy;

figure;
subplot(2,2,1);
plot(beep);
xlabel('Time');
ylabel('Amplitude');
title('Clean beep, time domain');

subplot(2,2,2);
plot(abs(fft(beep,8000)));
xlabel('Frequency/Hz');
ylabel('Magnitude');
title('Clean beep, freq domain');

subplot(2,2,3);
plot(beeps_noisy);
xlabel('Time');
ylabel('Amplitude');
title('Noisy beeps, time domain');

subplot(2,2,4);
plot(abs(fft(beeps_noisy,8000)));
xlabel('Frequency/Hz');
ylabel('Magnitude');
title('Noisy beeps, freq domain');

figure;
subplot(1,2,1);
spectrogram(beep, hamming(512), 256, 512, 8000, 'yaxis');
title('Clean beep');

subplot(1,2,2);
spectrogram(beeps_noisy, hamming(512), 256, 512, 8000, 'yaxis');
title('Noisy beeps');

%% Plot time domain, fft for 'eleven' and other words
eleven;
Eleven = Eleven(1:4096);
eleven_noisy3;
seven = [seven; zeros(4096-length(seven),1)];
opening = doors(11906:end);
kw_eleven;

all_time = [eleven Eleven eleven_noisy3 seven opening kw_eleven];
names = ["Clean eleven", "Another eleven", "Noisy eleven synthetic", "Seven", "Opening", "KW eleven"];

fftlen = 4096;
eleven_fft = abs(fft(eleven, fftlen));
Eleven_fft = abs(fft(Eleven, fftlen));
eleven_noisy3_fft = abs(fft(eleven_noisy3, fftlen));
seven_fft = abs(fft(seven, fftlen));
opening_fft = abs(fft(opening, fftlen));
kw_eleven_fft = abs(fft(kw_eleven, fftlen));

all_fft = [eleven_fft Eleven_fft eleven_noisy3_fft seven_fft opening_fft kw_eleven_fft];
half_fft = zeros(2048,6);
for i=1:6
    tmp = all_fft(:,i);
    half_fft(:,i) = tmp(1:2048);
end

figure;
for i=1:6
    subplot(6,2,2*i-1);
    plot(all_time(:,i));
    xlabel('Time');
    ylabel('Amplitude');
    title(names(i));
    
    subplot(6,2,2*i);
    plot(half_fft(:,i));
    xlabel('Freq');
    ylabel('Magnitude');
    title(names(i));
end

figure;
for i=1:6
    subplot(2,3,i);
    spectrogram(all_time(:,i), hamming(512), 256, 512, 8000, 'yaxis');
    title(names(i));
end

%% Correlation for eleven

eleven;
Eleven = Eleven(1:4096);
eleven_noisy3;
seven = [seven; zeros(4096-length(seven),1)];
opening = doors(11906:end);
kw_eleven;

all_time = [eleven Eleven eleven_noisy3 seven opening kw_eleven];
names = ["Clean eleven", "Another eleven", "Noisy eleven synthetic", "Seven", "Opening", "KW eleven"];

fftlen = 4096;
eleven_fft = abs(fft(eleven, fftlen));
Eleven_fft = abs(fft(Eleven, fftlen));
eleven_noisy3_fft = abs(fft(eleven_noisy3, fftlen));
seven_fft = abs(fft(seven, fftlen));
opening_fft = abs(fft(opening, fftlen));
kw_eleven_fft = abs(fft(kw_eleven, fftlen));

all_fft = [eleven_fft Eleven_fft eleven_noisy3_fft seven_fft opening_fft kw_eleven_fft];

corr = [];

for i=1:6
    R = corrcoef(eleven_fft, all_fft(:,i));
    corr = [corr R(1,2)];
end

%% 512-sample frames, 50% overlap, span over 4096 samples
fftbins =512;
%frame overlap
clean = eleven;
N = length(clean);
window = hamming(fftbins);
spec = zeros(fftbins,1);
for w =1 :15
    frame = clean(fftbins/2*(w-1)+1:fftbins/2*(w+1));
    frame_w = window.*frame;
    spec = spec + abs(fft(frame_w, fftbins));
end

% save eleven into txt file for reading into c
handle = fopen('elevenfft1024.txt', 'wt');
fprintf(handle, 'float meanA = %e\n', mean(spec));
fprintf(handle, 'float stdA = %e\n', std(spec));
fprintf(handle, 'float elevenfft[] = {');

for i = 1: length(spec)-1
    fprintf(handle,'%e, ',spec(i));
end

fprintf(handle, '%e}; \n', spec(length(spec)));
fclose('all');
