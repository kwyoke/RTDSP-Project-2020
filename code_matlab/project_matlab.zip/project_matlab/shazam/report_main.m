clear all
clc
clear_hashtable;

%% read audio inputs
[eleven, Fs] = audioread('../eleven_8k.wav');
eleven = eleven(1000:5095);
[beep, Fs] = audioread('../beep_8k.wav');
[journey, Fs] = audioread('../journey_no_noise_8k.wav');
[noisy, Fs] = audioread('../noisy_journey_8k.wav');
beeps_noisy = journey(36001:36000+length(eleven));
six = journey(112001:112000+length(eleven));
talking = noisy(10001:10000+length(eleven));
eleven_noisy = eleven + beeps_noisy; %synthetic noisy eleven
eleven_noisy2 = eleven + six; %six and eleven mixed
eleven_noisy3 = eleven + talking;
[kw_eleven, Fs] = audioread('../kw_eleven.wav');
kw_eleven = kw_eleven(6000:10095);
[Eleven2, Fs] = audioread('../Eleven8k.wav');
Eleven = Eleven2(175000:179905);
beeps2 = Eleven2(165000:170000);
doors = journey(128000:144000);
seven = journey(278000:282000);

%% Run shazam algo
clear_hashtable;
eleven;
Eleven = Eleven(1:4096);
eleven_noisy3;
seven = [seven; zeros(4096-length(seven),1)];
opening = doors(11906:end);
kw_eleven;

all_time = [eleven Eleven eleven_noisy3 seven opening kw_eleven];

[L_eleven,S_eleven,T_eleven,maxes_eleven] = find_landmarks(eleven,Fs);
H_eleven = landmark2hash(L_eleven); 
save_hashes(H_eleven);
%Run matching
scores = [];
for i=1:6
    R = match_query(all_time(:,i),Fs);
    if isempty(R)
        scores = [scores 0];
    else
        scores = [scores R(2)];
    end
end

%% Show landmarks
figure;
noisy = Eleven2;
noisy2 = eleven_noisy3;
noisy3 = seven;
[L_noisy,S_noisy,T_noisy,maxes_noisy] = find_landmarks(noisy,Fs);
[L_noisy2,S_noisy2,T_noisy2,maxes_noisy2] = find_landmarks(noisy2,Fs);
[L_noisy3,S_noisy3,T_noisy3,maxes_noisy3] = find_landmarks(noisy3,Fs);
[L_eleven,S_eleven,T_eleven,maxes_eleven] = find_landmarks(eleven,Fs);
subplot(2,2,1);
show_landmarks(eleven,Fs,L_eleven);
title('Clean eleven');
xlabel('Time/seconds');
ylabel('Freq/Hz');
subplot(2,2,2);
show_landmarks(noisy,Fs,L_noisy);
title('Another eleven');
xlabel('Time/seconds');
ylabel('Freq/Hz');

subplot(2,2,3);
show_landmarks(noisy2,Fs,L_noisy2);
title('Noisy eleven synthetic');
xlabel('Time/seconds');
ylabel('Freq/Hz');

subplot(2,2,4);
show_landmarks(noisy3,Fs,L_noisy3);
title('Seven');
xlabel('Time/seconds');
ylabel('Freq/Hz');
